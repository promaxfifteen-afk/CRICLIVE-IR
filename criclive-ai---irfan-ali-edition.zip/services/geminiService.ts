import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY || ''; // Ideally loaded from env
const ai = new GoogleGenAI({ apiKey });

export const getAICommentary = async (
  event: string, 
  batterName: string, 
  bowlerName: string, 
  score: string
): Promise<string> => {
  if (!apiKey) return "AI Analysis unavailable (Missing API Key).";

  try {
    const prompt = `
      You are an energetic cricket commentator like Ravi Shastri or Danny Morrison.
      The match situation is: Score ${score}.
      Event just happened: ${event} runs/wicket.
      Batter: ${batterName}. Bowler: ${bowlerName}.
      
      Write a VERY SHORT, one-sentence exciting commentary line about this specific ball. 
      Use cricket slang if appropriate. Do not use quotes.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text || "What a moment in the match!";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "The crowd is going wild after that delivery!";
  }
};

export const getMatchSummary = async (score: string, overs: string): Promise<string> => {
  if (!apiKey) return "Match analysis unavailable.";

  try {
    const prompt = `
      Analyze the current cricket match state:
      Score: ${score}
      Overs: ${overs}
      
      Provide a brief 2-sentence summary of which team has the upper hand and what the batting team needs to do.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text || "The match is evenly poised at this stage.";
  } catch (error) {
    return "Calculating match probability...";
  }
};