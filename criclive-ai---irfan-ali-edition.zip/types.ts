export interface Player {
  id: string;
  name: string;
  role: 'Batsman' | 'Bowler' | 'All-Rounder' | 'Wicketkeeper';
  runs: number;
  balls: number;
  fours: number;
  sixes: number;
  isStriker: boolean;
  out: boolean;
}

export interface Bowler {
  id: string;
  name: string;
  overs: number;
  runsConceded: number;
  wickets: number;
}

export interface CommentaryLine {
  id: string;
  over: number;
  ball: number;
  text: string;
  event: string; // '4', '6', 'W', '1', '0', etc.
  isAI?: boolean;
}

export interface MatchState {
  totalRuns: number;
  wickets: number;
  overs: number;
  balls: number; // Balls in current over (0-6)
  currentRunRate: number;
  target: number;
  battingTeam: string;
  bowlingTeam: string;
  isMatchActive: boolean;
  isMatchFinished: boolean;
}