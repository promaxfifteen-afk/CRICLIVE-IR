import { Player, Bowler } from './types';

export const INITIAL_BATTERS: Player[] = [
  { id: '1', name: 'Rohit Sharma', role: 'Batsman', runs: 45, balls: 32, fours: 4, sixes: 2, isStriker: true, out: false },
  { id: '2', name: 'Virat Kohli', role: 'Batsman', runs: 38, balls: 28, fours: 3, sixes: 1, isStriker: false, out: false },
  { id: '3', name: 'Suryakumar Yadav', role: 'Batsman', runs: 0, balls: 0, fours: 0, sixes: 0, isStriker: false, out: false },
  { id: '4', name: 'Rishabh Pant', role: 'Wicketkeeper', runs: 0, balls: 0, fours: 0, sixes: 0, isStriker: false, out: false },
  { id: '5', name: 'Hardik Pandya', role: 'All-Rounder', runs: 0, balls: 0, fours: 0, sixes: 0, isStriker: false, out: false },
];

export const INITIAL_BOWLERS: Bowler[] = [
  { id: 'b1', name: 'Shaheen Afridi', overs: 3.0, runsConceded: 24, wickets: 0 },
  { id: 'b2', name: 'Naseem Shah', overs: 3.0, runsConceded: 18, wickets: 0 },
  { id: 'b3', name: 'Haris Rauf', overs: 0, runsConceded: 0, wickets: 0 },
];

export const TEAMS = {
  batting: 'India',
  bowling: 'Pakistan'
};